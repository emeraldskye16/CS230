package com.gamingroom;

public class Entity {
	//set attributes
	private long ID;
	private String Name;
	
	//default constructor
	private Entity() {
		
	}
	
	//new constructor with ID and Name parameters
	//passed in
	public Entity (long ID, String Name) {
		
		//call to default constructor
		this();
		this.ID = ID;
		this.Name = Name;
		
	}
	
	public long getID() {
		return ID;
		
	}
	
	public String getName() {
		return Name;
		
	}
	
	public String toString() {
		return "Entity [ID = " + ID + ", Name = " + Name + "]";
		
	}
}
